package cpsc331.assignment2;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * <b><u>CPSC 331 ASSIGNMENT #2: IMPLEMENTATION AND APPLICATION OF A STACK</b></u>
 * 
 * <p><tt>TestCheckBrackets</tt> uses <tt>JUnit</tt> to call <tt>isNested</tt> with 
 * various types of strings as arguments to test for correct functionality of
 * the method.
 * 
 * The final eight tests (<tt>TestSample#</tt>) are taken from the descriptions of the problem in <i>Assignment 2
 * Problem 2</i>. Credit to Dr. Wayne Eberly.
 * 
 * @author Bryan Huff       (UCID 10096604)
 * @author Michael Hung     (UCID 10099049)
 * @author Arnold Padillo   (UCID 10097013)
 */

public class TestCheckBrackets extends CheckBrackets
{
        
    /* Testing for properly nested input of 1 Argument : Should return String output.
     * Message Returned : "(String) is properly nested." */
     
     @Test
     public void TestOneArgNested()
     {
        assertTrue("Should return True", isNested("[]"));
     }
     
    /* Testing for improperly nested input of 1 Argument : Should return String output.
     * Message Returned : "<String> is not properly nested." */
     
     @Test
     public void TestOneArgNotNested()
     {
        assertFalse("Should return False", isNested("[)"));
     }
     
    /* Testing for improperly paired input of 1 Argument : Should return String output.
     * Message Returned : "<String> is not properly nested." */
     
     @Test
     public void TestImproperPair1()
     {
        assertFalse("Should return False", isNested("([)]"));
     }
     
     /* Testing for improperly paired input of 1 Argument : Should return String output.
      * Message Returned : "<String> is not properly nested." */
      
      @Test
      public void TestImproperPair2()
      {
         assertFalse("Should return False", isNested(")("));
      }
      
      /* Testing for improperly paired input of 1 Argument : Should return String output.
       * Message Returned : "<String> is not properly nested." */
       
       @Test
       public void TestImproperPair3()
       {
          assertFalse("Should return False", isNested("]["));
       }
     
    /* Testing for properly paired input of 1 Argument : Should return String output.
     * Message Returned : "<String> is properly nested." */
     
     @Test
     public void TestProperPair()
     {
        assertTrue("Should return True", isNested("[()]"));
     }
     
    /* Testing for input with only characters : Should return String output.
     * Message Returned : "<String> is properly nested." */
     
     @Test
     public void TestCharactersOnly()
     {
        assertTrue("Should return true", isNested("asbs"));
     }
     
    /* Testing for input with an assortment of matching brackets and random letters : Should return String output.
     * Message Returned : "<String> is properly nested." */
     
     @Test
     public void TestCharsandBrackets1()
     {
        assertTrue("Should return true", isNested("()abc[]"));
     }
     
    /* Testing for input with an assortment of non matching brackets and random letters: Should return string output.
     * Message Returned : " <String> is not properly nested. " */
     
     @Test
     public void TestCharsandBrackets2()
     {
        assertFalse("Should return false", isNested("(abc]()"));
     }
     
     /* Testing for input with an incomplete pair of parentheses: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestIncompletePair1()
     {
         assertFalse("Should return false", isNested("(()"));
     }
     
     /* Testing for input with an incomplete pair of parentheses: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestIncompletePair2()
     {
         assertFalse("Should return false", isNested("[[]"));
     }
     
     /* Testing for input with an incomplete pair of parentheses: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestIncompletePair3()
     {
         assertFalse("Should return false", isNested("())"));
     }
     
     /* Testing for input with an incomplete pair of parentheses: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestIncompletePair4()
     {
         assertFalse("Should return false", isNested("[]]"));
     }
     
     /* Testing for properly nested character with square parentheses: Should return string output.
      * Message returned: " <String> is properly nested " */
      
     @Test
     public void TestSample1()
     {
         assertTrue("Should return true", isNested("[a]"));
     }
     
     /* Testing for properly nested input without parenthesis: Should return string output.
      * Message returned: " <String> is properly nested " */
      
     @Test
     public void TestSample2()
     {
         assertTrue("Should return true", isNested("bc"));
     }
     
     /* Testing for properly nested input: Should return string output.
      * Message returned: " <String> is properly nested " */
      
     @Test
     public void TestSample3()
     {
         assertTrue("Should return true", isNested("[(a)]"));
     }

     /* Testing for properly nested input with various character and parenthesis combinations: Should return string output.
      * Message returned: " <String> is properly nested " */
      
     @Test
     public void TestSample4()
     {
         assertTrue("Should return true", isNested("[](a[b])"));
     }
     
     /* Testing for improperly nested input with missing right parenthesis: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestSample5()
     {
         assertFalse("Should return false", isNested("((a)"));
     }
     
     /* Testing for improperly nested input with improper pairing: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestSample6()
     {
         assertFalse("Should return false", isNested("[(a])"));
     }
     
     /* Testing for improperly nested input with missing left parenthesis: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestSample7()
     {
         assertFalse("Should return false", isNested("(a))"));
     }
     
     /* Testing for improperly nested input with pairing in the wrong order: Should return string output.
      * Message returned: " <String> is not properly nested " */
      
     @Test
     public void TestSample8()
     {
         assertFalse("Should return false", isNested(")a("));
     }
}