package cpsc331.assignment2;

import cpsc331.collections.adts.Stack;
import cpsc331.collections.basic.SinglyLinkedList;
import cpsc331.collections.exceptions.EmptyStackException;

/**
 * <b><u>CPSC 331 ASSIGNMENT #2: IMPLEMENTATION AND APPLICATION OF A STACK</b></u>
 * 
 * <p><tt>ListStack</tt> uses the provided <tt>Stack</tt> interface and <tt>SinglyLinkedList</tt> class
 * to simulate a <tt>Stack</tt> using a singly linked list.  
 * 
 * @author Bryan Huff       (UCID 10096604)
 * @author Michael Hung     (UCID 10099049)
 * @author Arnold Padillo   (UCID 10097013)
 */

public class ListStack implements Stack<Object>
{
    private SinglyLinkedList<Object> S;

    public ListStack() // Default Constructor: initializes SinglyLinkedList S to simulate a Stack
    {
        this.S = new SinglyLinkedList<Object>();
    }
    
    @Override
    public void push(Object X) // Adds a new Object onto the top of the simulated Stack
    {
         this.S.addHead(X);
         return;
    }
    
    @Override 
    public Object peek() // Returns the newest Object that was added to the Stack. If the Stack is empty, throw an exception.
    {
        if (this.S.isEmpty()) 
            throw new EmptyStackException();
        
        else
            return this.S.head();
    }
    
    @Override
    public Object pop() // Return the newest Object that was added to the Stack and remove it from the Stack.
    {
        return this.S.removeHead();
    }
    
    @Override
    public boolean isEmpty() // Test for if the Stack is empty. Returns a Boolean value that corresponds to the result.
    {
        return this.S.isEmpty();
    }

}
