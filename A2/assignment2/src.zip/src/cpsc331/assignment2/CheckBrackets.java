package cpsc331.assignment2;

/**
 * <b><u>CPSC 331 ASSIGNMENT #2: IMPLEMENTATION AND APPLICATION OF A STACK</b></u>
 * 
 * <p><tt>CheckBrackets</tt> solves the "Properly Nested String Recognition" computational problem
 * as required in <i>Assignment 2 Problem 4</i> by implementing an algorithm that makes use of the class,
 * <tt>ListStack</tt>, which we developed in <i>Assignment 2 Problem 1</i>, which is an implementation of a
 * <tt>SinglyLinkedList</tt>. 
 * 
 * @author Bryan Huff       (UCID 10096604)
 * @author Michael Hung     (UCID 10099049)
 * @author Arnold Padillo   (UCID 10097013)
 */

public class CheckBrackets
{
    /**
     * Performs a check on the input provided on the command line. If there is more than one
     * argument provided, or zero arguments are provided, a corresponding message is printed 
     * and the program terminates. Otherwise, if there is exactly one argument provided (that is 
     * a character string), we call <tt>isNested</tt> and a corresponding message is printed
     * depending on whether or not the string is, in fact, properly nested.
     * 
     * @param args A <tt>String</tt> <tt>Array</tt> of the arguments provided on the command-line. 
     * In <tt>CheckBrackets</tt>, there should be exactly zero or one character strings provided
     * as input.
     */
    
    public static void main(String[] args)
    {
        if (args.length > 1)
        {
            System.out.println("You must provide exactly one character string as input.");
            System.exit(0);
        }
        
        else if (args.length == 0)
        {
            System.out.println("The empty string is properly nested.");
            System.exit(0);
        }
        
        String aString = args[0];
            
        if(isNested(aString))
            System.out.println(aString + " is properly nested.");
        
        else
            System.out.println(aString + " is not properly nested.");
    }

    /**
     * This method uses one <tt>String</tt>-type argument, creates an <tt>Array</tt> with a number of 
     * elements equal to the number of characters in the <tt>String</tt>, and assigns each character to 
     * their corresponding <tt>Array</tt> element. We traverse the array, "pushing" left parentheses in 
     * when they are encountered and "popping" them out when a right parentheses is encountered. 
     * 
     * @param input A non-empty <tt>String</tt>.
     * 
     * @return <b><tt>true</b></tt> when <tt>input</tt> is properly nested, i.e.
     * every parenthesis is part of a pair with each respective left parenthesis preceding the right one.
     * <p> <b><tt>false</b></tt> when <tt>input</tt> is not properly nested, i.e. either a parenthesis
     * is missing its counterpart, or a right parenthesis precedes its left counterpart.
     */
    
    public static boolean isNested(String input)
    {
        // Assertion: A single String, input, with length > 0, has been provided as input.
        
        int i = 0;
        char[] symbols = input.toCharArray();
        ListStack S = new ListStack();
        
        /* Loop Invariant (Incomplete - cannot be used to prove correctness):
         *      1. input is a String with length > 0
         *      2. The value of i is between 0 and input.length(), inclusive
         *      3. symbols is an array of characters with at least one element
         *
         * Bound Function: (symbols.length - 1) - i
         */  
        
        /* Assertion - Before Loop Execution:
         *      1. The loop invariant is satisfied
         *      2. i is equal to 0
         *      3. ListStack S is empty
         */
        
        while(i < symbols.length)
        {
        /* Assertion - Before Each Iteration:
         *      1. The loop invariant is satisfied
         *      2. i is between 0 and (input.length() - 1), inclusive
         */
            
            if ((symbols[i] == '(') || (symbols[i] == '['))
            {
                S.push(symbols[i]); 
                /* Assertions: 
                 *      1. symbols[i] is '(' or '['
                 *      2. Assertion: '(' or ')' has been pushed onto the ListStack S, which is now nonempty
                 */
            }
            
            else if ((symbols[i] == ')') || (symbols[i] == ']'))
            {
                if (S.isEmpty())
                {
                    return false; 
                    /* Assertions: 
                     *      1. ListStack S is empty; a ')' or ']' precedes '(' or '[', respectively
                     *      2. Boolean false has been returned, so algorithm halts and program terminates
                     *      3. input is not properly nested.
                     */
                }
            
                else if (((S.peek().toString().equals("(")) && (symbols[i] == ']')) ||  ((S.peek().toString().equals("[") && (symbols[i] == ')'))))
                {
                    return false;
                    /* Assertions: 
                     *      1. An incorrect pairing has been made
                     *      2. Boolean false has been returned, so algorithm halts and program terminates
                     *      3. input is not properly nested.
                     */
                }
                
                else if  (((S.peek().toString().equals("(")) && (symbols[i] == ')')) ||  ((S.peek().toString().equals("[") && (symbols[i] == ']'))))
                {
                    S.pop();
                    // Assertion: A correct pairing of parentheses has been made and the stack height is decreased by one.
                }
            }
            
            i++;
            
        /* Assertion - After Each Iteration:
         *      1. The loop invariant is satisfied
         *      2. i is between 1 and input.length(), inclusive
         */
        }
        /* Assertion - After Loop Execution:
         *      1. The loop invariant is satisfied
         *      2. i is equal to input.length
         */
        
        if (!S.isEmpty())
            return false;
            /* Assertions: 
             *      1. ListStack S is not empty, i.e. at least one left parenthesis has not been paired
             *      2. Boolean false has been returned, so algorithm halts and program terminates
             *      3. input is not properly nested.
             */
            
        return true;
        /* Assertions: 
         *      1. ListStack S is empty
         *      2. Boolean true has been returned, so algorithm halts and program terminates
         *      3. input is properly nested.
         */
    }
}